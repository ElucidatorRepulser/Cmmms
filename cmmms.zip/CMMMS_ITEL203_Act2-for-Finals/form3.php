<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Application for
Postal Id Card</title>
 <link rel="stylesheet" href="css/form3.css">
</head>
<!--embedded-->
<style>
*{
	font-family: Times New Roman;
}
input[type=text], select {
	display: inline-block;
	border: 1px solid #000;
	border-radius: 2px;
	box-sizing: border-box;
}
input[type=submit] {
	background-color: #c4a136;
	color: white;
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	border-radius: 4px;
	cursor: pointer;
}

input[type=submit]:hover  {
	background-color: #b58926;
}

input[type=reset] {
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	border-radius: 4px;
	cursor: pointer;
}

input[type=reset]:hover  {
	background-color: #afafaf;
}
</style>

<body>
  <!--header-->
<div class="form__container">
  <div class="header__container">
    <div class="header__card--1">

      <div class="header-inside__container--1">
  <img src="img\logo3.png" alt="logo" width="300" height="70" style="justify-content:center">
      <p style="justify-content:center"><b>PURPOSEAPPLICATION FOR POSTAL ID CARDAPPLICANT’S</b></p>
      </div>

      <div class="header-inside__container--2">
        <p style="font-size: 20px">
          Republic of the Philippines<br>
        <b> PHILIPPINE POSTAL CORPORATION</b> <br>
        <p style="font-size: 10px;font-family: sans-serif">PLEASE READ THE GENERAL TERMS AND CONDITIONS AT THE BACK BEFORE ACCOMPLISHINGTHIS <br>
           FORM. PRINT ALL INFORMATION IN <b>CAPITAL LETTERS</b> AND <b>USE BLACK INK ONLY</b>.</p>
        </p>
      </div>
    </div>

    <div class="header__card--2">
<div class="header-upperright__container" style="border: 1px solid black; align: right; padding: 10px; width: 270px">
  <!--form-->
<form action="backend/form3_db.php" method="post">
    PID Form No.
    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		<input type="text" name="PID_Form_No" size="10" id="PID_Form_No"> <br>
    <label for="datemin">Revision No.(Date)</label>
     <input type="date" id="datemin" name="Revision_No" id="Revision_No"> <br>
    Application Control No:
		<input type="text" name="Application_Control_No" size="10" id="Application_Control_No"> <br>
    Accepting Post Office Code:
    &nbsp
		<input type="text" name="Accepting_Post_Office_Code" size="5" id="Accepting_Post_Office_Code"> <br>
    Accepting Post Office Name:
    <input type="text" name="PON" size="5"> <br>
    Or No.
    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
		<input type="text" name="OrNo" size="17"> <br>
    <label for="ordate">Or Date</label>
    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
     <input type="date" id="ordate" name="ordate"> <br>
    <hr>
    <b>Postal Reference No.</b>
    &nbsp &nbsp
		<input type="text" name="PRN" size="10"> <br>
</div>
    </div>
  </div>
  <hr>
  <p style="text-align: center"><b>REPLACEMENTPART I - TO BE FILLED OUT BY THE APPLICANT</b></p>
  <hr>
  <p style="text-align: center"><b>A. APPLICATION TYPE</b></p>
  <hr>
  &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp<b>Purpose</b>&nbsp &nbsp &nbsp
				<input type="checkbox" name="Initial"><b>Initial</b><br>
        &nbsp &nbsp &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp
         &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp&nbsp &nbsp
         &nbsp &nbsp
				<input type="checkbox" name="Renewal"><b>Renewal</b><br>
        &nbsp &nbsp &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp &nbsp
        &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp&nbsp &nbsp&nbsp &nbsp &nbsp
				<input type="checkbox" name="Card Replacement"><b>Card Replacement</b><br/><br/>
        <div class="checkbox__container" style="align:center; text-align:center; justify-content:center">
				<input type="checkbox" name="Card Replacement">Amendment of Name
				<input type="checkbox" name="Card Replacement">Replacement of Lost Card
				<input type="checkbox" name="Card Replacement">Amendment of Biographic Data
				<input type="checkbox" name="Card Replacement">Amendment of Authenticating Finger
				<input type="checkbox" name="Card Replacement"> Replacement of Damage Card
				<input type="checkbox" name="Card Replacement"> Others
        </div>
        <hr>
  <p style="text-align: center"><b>B. APPLICATION DETAILS</b></p>
  <hr>
  <!--Table-->
    <table style="width:100%; border: 1px solid black;border-collapse: collapse">
  <tr>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">APPLICANT'S NAME(FIRSTNAME) <br><input type="text" name="PFN" size="20"placeholder="   Input First Name Here"> <br> <br>
</th>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">MIDDLE NAME <br><input type="text" name="PFN" size="20"placeholder="   Input Middle Name Here"> <br> <br></th>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">LAST NAME <br><input type="text" name="PFN" size="20"placeholder="   Input Last Name Here"> <br> <br> </th>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">SUFFIX <br><input type="text" name="PFN" size="20"placeholder="   Input Suffix Here"> <br> <br></th>
  </tr>
  </table>
    <table style="width:100%; border: 1px solid black;border-collapse: collapse">
  <tr>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">
       &nbsp&nbsp &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp &nbsp
GENDER &nbsp&nbsp &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp &nbsp
<br>
        <center><select name="gender" id="gender">
            <option value="1">Male</option>
            <option value="2">Female</option>
        </select></center>
</th>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">DATE OF BIRTH (MM/DD/YYYY) <br><input type="date" id="DOB" name="DOB">
 <br></th>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">PLACE OF BIRTH (CITY/MUNICIPALITY) <br><input type="text" name="PFN" size="20"placeholder="   City/Municipality"> <br></th>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">PROVINCE <br><input type="text" name="PFN" size="20"placeholder="   Input Province Here">  <br></th>
    <th style="border: 1px solid black;border-collapse: collapse; padding: 5px">COUNTRY <br><input type="text" name="PFN" size="20"placeholder="   Input Country Here">  <br></th>
  </tr>
  </table>
  <!--footer-->
      <!--save reset-->
      <div class="savereset__container">
				<input type="submit" name="submit" value="SAVE">
				<input type="Reset" name="clear" Value="RESET">
        <button type="submit" name="submit">Submit</button>
			</div>
      </form>
</div>
<!--next preview back-->
	<div class="btn__container">
	<div class="btn__wrapper--1">
					<button type="button" ><a href="logout.php" style="text-decoration: none; color: #131313">Logout</a></button>
	</div>
	<div class="btn__wrapper--2">
					<button type="button" ><a href="f3_records.php" style="text-decoration: none; color: #131313">View Records</a></button>
	</div>
</body>
</html>
