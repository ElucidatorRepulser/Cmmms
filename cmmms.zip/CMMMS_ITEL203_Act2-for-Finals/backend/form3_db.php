<?php
	$PID_Form_No = $_POST['PID_Form_No'];
	$Revision_No = $_POST['Revision_No'];
	$Application_Control_No = $_POST['Application_Control_No'];
	$Accepting_Post_Office_Code = $_POST['Accepting_Post_Office_Code'];

	// Database connection
	$conn = new mysqli('localhost','root','','test');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into registration(PID_Form_No, Revision_No, Application_Control_No, Accepting_Post_Office_Code) values(?, ?, ?, ?)");
		$stmt->bind_param("ssss", $PID_Form_No, $Revision_No, $Application_Control_No, $Accepting_Post_Office_Code);
		$execval = $stmt->execute();
		echo $execval;
		echo "Registration successfully...";
		$stmt->close();
		$conn->close();
	}
?>
