<?php
include 'database.php';
#1
if(count($_POST)>0){
	if($_POST['type']==1){
		$PID_Form_No=$_POST['PID_Form_No'];
		$Revision_No=$_POST['Revision_No'];
		$Application_Control_No=$_POST['Application_Control_No'];
		$Accepting_Post_Office_Code=$_POST['Accepting_Post_Office_Code'];
		$Accepting_Post_Office_Name=$_POST['Accepting_Post_Office_Name'];
		$Or_No=$_POST['Or_No'];
		$Or_Date=$_POST['Or_Date'];
		$Postal_Reference_No=$_POST['Postal_Reference_No'];
		$Initial=$_POST['Initial'];
		$Renewal=$_POST['Renewal'];
		$Card_Replacement=$_POST['Card_Replacement'];
		$Amendment_of_Name=$_POST['Amendment_of_Name'];
		$Replacement_of_Lost_Card=$_POST['Replacement_of_Lost_Card'];
		$Amendment_of_Biographic_Data=$_POST['Amendment_of_Biographic_Data'];
		$Amendment_of_Authenticating_Finger=$_POST['Amendment_of_Authenticating_Finger'];
		$Replacement_of_Damage_Card=$_POST['Replacement_of_Damage_Card'];
		$Others=$_POST['Others'];
		$First_Name=$_POST['First_Name'];
		$Middle_Name=$_POST['Middle_Name'];
		$Last_Name=$_POST['Last_Name'];
		$Suffix=$_POST['Suffix'];
		$Gender=$_POST['Gender'];
		$Date_of_Birth=$_POST['Date_of_Birth'];
		$Place_of_Birth=$_POST['Place_of_Birth'];
		$Province=$_POST['Province'];
		$Country=$_POST['Country'];
		$sql = "INSERT INTO `f3_records`( `PID_Form_No`, `Revision_No`,`Application_Control_No`,`Accepting_Post_Office_Code`,`Accepting_Post_Office_Name`,`Or_No`,`Or_Date`,`Postal_Reference_No`,`Initial`,`Renewal`,`Card_Replacement`,`Amendment_of_Name`,	`Replacement_of_Lost_Card`,`Amendment_of_Biographic_Data`,`Amendment_of_Authenticating_Finger`,`Replacement_of_Damage_Card`,`Others`,`First_Name`,`Middle_Name`,`Last_Name`,`Suffix`,`Gender`,`Date_of_Birth`,`Place_of_Birth`,`Province`,'Country')
		VALUES ('$PID_Form_No','$Revision_No','$Application_Control_No','$Accepting_Post_Office_Code','$Accepting_Post_Office_Name','$Or_No','$Or_Date','$Postal_Reference_No','$Initial','$Renewal','$Card_Replacement','$Amendment_of_Name','$Replacement_of_Lost_Card','$Amendment_of_Biographic_Data','$Amendment_of_Authenticating_Finger','$Replacement_of_Damage_Card','$Others','$First_Name','$Middle_Name','$Last_Name','$Suffix','$Gender','$Date_of_Birth','$Place_of_Birth','$Province','$Country')";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
#2
if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
		$PID_Form_No=$_POST['PID_Form_No'];
		$Revision_No=$_POST['Revision_No'];
		$Application_Control_No=$_POST['Application_Control_No'];
		$Accepting_Post_Office_Code=$_POST['Accepting_Post_Office_Code'];
		$Accepting_Post_Office_Name=$_POST['Accepting_Post_Office_Name'];
		$Or_No=$_POST['Or_No'];
		$Or_Date=$_POST['Or_Date'];
		$Postal_Reference_No=$_POST['Postal_Reference_No'];
		$Initial=$_POST['Initial'];
		$Renewal=$_POST['Renewal'];
		$Card_Replacement=$_POST['Card_Replacement'];
		$Amendment_of_Name=$_POST['Amendment_of_Name'];
		$Replacement_of_Lost_Card=$_POST['Replacement_of_Lost_Card'];
		$Amendment_of_Biographic_Data=$_POST['Amendment_of_Biographic_Data'];
		$Amendment_of_Authenticating_Finger=$_POST['Amendment_of_Authenticating_Finger'];
		$Replacement_of_Damage_Card=$_POST['Replacement_of_Damage_Card'];
		$Others=$_POST['Others'];
		$First_Name=$_POST['First_Name'];
		$Middle_Name=$_POST['Middle_Name'];
		$Last_Name=$_POST['Last_Name'];
		$Suffix=$_POST['Suffix'];
		$Gender=$_POST['Gender'];
		$Date_of_Birth=$_POST['Date_of_Birth'];
		$Place_of_Birth=$_POST['Place_of_Birth'];
		$Province=$_POST['Province'];
		$Country=$_POST['Country'];
		$sql = "UPDATE `f3_records` SET `PID_Form_No`='$PID_Form_No',`Revision_No`='$Revision_No',`Application_Control_No`='$Application_Control_No',`Accepting_Post_Office_Code`='$Accepting_Post_Office_Code' `Accepting_Post_Office_Name`='$Accepting_Post_Office_Name',`Or_No`='Or_No',`Or_Date`='$Or_Date',`Postal_Reference_No`='$Postal_Reference_No,`Initial`='$Initial,`Renewal`='$Renewal,`Card_Replacement`='$Card_Replacement,`Amendment_of_Name`='$Amendment_of_Name,`Replacement_of_Lost_Card`='$Replacement_of_Lost_Card,`Amendment_of_Biographic_Data`='$Amendment_of_Biographic_Data,`Amendment_of_Authenticating_Finger`='$Amendment_of_Authenticating_Finger,`Replacement_of_Damage_Card`='$Replacement_of_Damage_Card,`Others`='$Others,`First_Name`='$First_Name,`Middle_Name`='$Middle_Name,`Last_Name`='$Last_Name,`Suffix`='$Suffix,`Gender`='$Gender,`Date_of_Birth`='$Date_of_Birth,`Place_of_Birth`='$Place_of_Birth,`Province`='$Province,`Country`='$Country
		'WHERE id=$id";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "DELETE FROM `f3_records` WHERE id=$id ";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM f3_records WHERE id in ($id)";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>
