<?php
include 'backend/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>User Data</title>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/f3_records.css?v=<?php echo time(); ?>">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="ajax/ajax.js"></script>
</head>
<body>
    <div class="container">
	<p id="success"></p>
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
						<h2>Manage <b>Users</b></h2>
					</div>
					<div class="col-sm-6">
						<a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xE147;</i> <span>Add New User</span></a>
						<a href="JavaScript:void(0);" class="btn btn-danger" id="delete_multiple"><i class="material-icons">&#xE15C;</i> <span>Delete</span></a>
					</div>
                </div>
            </div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
						<th>
							<span class="custom-checkbox">
								<input type="checkbox" id="selectAll">
								<label for="selectAll"></label>
							</span>
						</th>
						<th>SL NO</th>
                        <th>PID_Form_No</th>
                        <th>Revision_No</th>
						<th>Application_Control_No</th>
                        <th>Accepting_Post_Office_Code</th>
                        <th>Or No</th>
						<th>Or Date</th>
                        <th>Postal Reference No</th>
						<th>Initial</th>
                        <th>Renewal</th>
                        <th>Card Replacement</th>						
						<th>Amendment of Name</th>
                        <th>Replacement of Lost Card</th>
						<th>Amendment of Biographic Data</th>
                        <th>Amendment of Authenticating Finger</th>
                        <th>Replacement of Damage Card</th>
						<th>Others</th>
                        <th>First Name</th>
						<th>Middle Name</th>
                        <th>Last Name</th>
                        <th>Suffix</th>						
                        <th>Gender</th>
						<th>Date of Birth</th>
                        <th>Place of Birth</th>
                        <th>Province</th>
						<th>Country</th>
                    </tr>
                </thead>
				<tbody>

				<?php
				$result = mysqli_query($conn,"SELECT * FROM f3_records");
					$i=1;
					while($row = mysqli_fetch_array($result)) {
				?>
				<tr id="<?php echo $row["id"]; ?>">
				<td>
							<span class="custom-checkbox">
								<input type="checkbox" class="user_checkbox" data-user-id="<?php echo $row["id"]; ?>">
								<label for="checkbox2"></label>
							</span>
						</td>
					<td><?php echo $i; ?></td>
					<td><?php echo $row["PID_Form_No"]; ?></td>
					<td><?php echo $row["Revision_No"]; ?></td>
					<td><?php echo $row["Application_Control_No"]; ?></td>
					<td><?php echo $row["Accepting_Post_Office_Code"]; ?></td>
					<td><?php echo $row["Accepting_Post_Office_Name"]; ?></td>
					<td><?php echo $row["Or_No"]; ?></td>
					<td><?php echo $row["Or_Date"]; ?></td>
					<td><?php echo $row["Postal_Reference_No"]; ?></td>
					<td><?php echo $row["Initial"]; ?></td>
					<td><?php echo $row["Renewal"]; ?></td>
					<td><?php echo $row["Card_Replacement"]; ?></td>
					<td><?php echo $row["Amendment_of_Name"]; ?></td>
					<td><?php echo $row["Replacement_of_Lost_Card"]; ?></td>
					<td><?php echo $row["Amendment_of_Biographic_Data"]; ?></td>
					<td><?php echo $row["Amendment_of_Authenticating_Finger"]; ?></td>
					<td><?php echo $row["Replacement_of_Damage_Card"]; ?></td>
					<td><?php echo $row["Others"]; ?></td>
					<td><?php echo $row["First_Name"]; ?></td>
					<td><?php echo $row["Middle_Name"]; ?></td>
					<td><?php echo $row["Last_Name"]; ?></td>
					<td><?php echo $row["Suffix"]; ?></td>
					<td><?php echo $row["Gender"]; ?></td>
					<td><?php echo $row["Date_of_Birth"]; ?></td>
					<td><?php echo $row["Place_of_Birth"]; ?></td>
					<td><?php echo $row["Province"]; ?></td>
					<td><?php echo $row["Country"]; ?></td>
					<td>
						<a href="#editEmployeeModal" class="edit" data-toggle="modal">
							<i class="material-icons update" data-toggle="tooltip"
							data-id="<?php echo $row["id"]; ?>"
							data-PID_Form_No="<?php echo $row["PID_Form_No"]; ?>"
							data-Revision_No="<?php echo $row["Revision_No"]; ?>"
							data-Application_Control_No="<?php echo $row["Application_Control_No"]; ?>"
							data-Accepting_Post_Office_Code="<?php echo $row["Accepting_Post_Office_Code"]; ?>"
							data-Accepting_Post_Office_Name="<?php echo $row["Accepting_Post_Office_Name"]; ?>"
							data-Or_No="<?php echo $row["Or_No"]; ?>"
							data-Or_Date="<?php echo $row["Or_Date"]; ?>"
							data-Postal_Reference_No="<?php echo $row["Postal_Reference_No"]; ?>"
							data-Initial="<?php echo $row["Initial"]; ?>"
							data-Renewal="<?php echo $row["Renewal"]; ?>"
							data-Card_Replacement="<?php echo $row["Card_Replacement"]; ?>"
							data-Amendment_of_Name="<?php echo $row["Amendment_of_Name"]; ?>"
							data-Replacement_of_Lost_Card="<?php echo $row["Replacement_of_Lost_Card"]; ?>"
							data-Amendment_of_Biographic_Data="<?php echo $row["Amendment_of_Biographic_Data"]; ?>"
							data-Amendment_of_Authenticating_Finger="<?php echo $row["Amendment_of_Authenticating_Finger"]; ?>"
							data-Replacement_of_Damage_Card="<?php echo $row["Replacement_of_Damage_Card"]; ?>"
							data-Others="<?php echo $row["Others"]; ?>"
							data-First_Name="<?php echo $row["First_Name"]; ?>"
							data-Middle_Name="<?php echo $row["Middle_Name"]; ?>"
							data-Last_Name="<?php echo $row["Last_Name"]; ?>"
							data-Suffix="<?php echo $row["Suffix"]; ?>"
							data-Gender="<?php echo $row["Gender"]; ?>"
							data-Date_of_Birth="<?php echo $row["Date_of_Birth"]; ?>"
							data-Place_of_Birth="<?php echo $row["Place_of_Birth"]; ?>"
							data-Province="<?php echo $row["Province"]; ?>"
							data-Country="<?php echo $row["Country"]; ?>"							
							title="Edit">&#xE254;</i>
						</a>
						<a href="#deleteEmployeeModal" class="delete" data-id="<?php echo $row["id"]; ?>" data-toggle="modal"><i class="material-icons" data-toggle="tooltip"
						 title="Delete">&#xE872;</i></a>
                    </td>
				</tr>
				<?php
				$i++;
				}
				?>
				</tbody>
			</table>

        </div>
    </div>
	<!-- Add Modal HTML -->
	<div id="addEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form id="user_form">
					<div class="modal-header">
						<h4 class="modal-title">Add User</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<div class="form-group">
							<label>PID_Form_No</label>
							<input type="PID_Form_No" id="PID_Form_No" name="PID_Form_No" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Revision_No</label>
							<input type="date" id="Revision_No_u" name="Revision_No"><br><br>
						</div>
						<div class="form-group">
							<label>Application_Control_No</label>
							<input type="Application_Control_No" id="Application_Control_No" name="Application_Control_No" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Accepting_Post_Office_Code</label>
							<input type="Accepting_Post_Office_Code" id="Accepting_Post_Office_Code" name="Accepting_Post_Office_Code" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Accepting_Post_Office_Name</label>
							<input type="Accepting_Post_Office_Name" id="Accepting_Post_Office_Name_u" name="Accepting_Post_Office_Name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Or_No</label>
							<input type="Or_No" id="Or_No_u" name="Or_No" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Or_Date</label>
							<input type="date" id="Or_Date_u" name="Or_Date"><br><br>
						</div>
						<div class="form-group">
							<label>Postal_Reference_No</label>
							<input type="Postal_Reference_No" id="Postal_Reference_No_u" name="Postal_Reference_No" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Initial</label>
							<input type="Initial" id="Initial_u" name="Initial" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Renewal</label>
							<input type="Renewal" id="Renewal_u" name="Renewal" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Card_Replacement</label>
							<input type="Card_Replacement" id="Card_Replacement_u" name="Card_Replacement" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Amendment_of_Name</label>
							<input type="Amendment_of_Name" id="Amendment_of_Name_u" name="Amendment_of_Name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Replacement_of_Lost_Card</label>
							<input type="Replacement_of_Lost_Card" id="Replacement_of_Lost_Card_u" name="Replacement_of_Lost_Card" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Amendment_of_Biographic_Data</label>
							<input type="Amendment_of_Biographic_Data" id="Amendment_of_Biographic_Data_u" name="Amendment_of_Biographic_Data" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Amendment_of_Authenticating_Finger</label>
							<input type="Amendment_of_Authenticating_Finger" id="Amendment_of_Authenticating_Finger_u" name="Amendment_of_Authenticating_Finger" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Replacement_of_Damage_Card</label>
							<input type="Replacement_of_Damage_Card" id="Replacement_of_Damage_Card_u" name="Replacement_of_Damage_Card" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Others</label>
							<input type="Others" id="Others_u" name="Others" class="form-control" required>
						</div>
						<div class="form-group">
							<label>First_Name</label>
							<input type="First_Name" id="First_Name_u" name="First_Name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Middle_Name</label>
							<input type="Middle_Name" id="Middle_Name_u" name="Middle_Name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Last_Name</label>
							<input type="Last_Name" id="Last_Name_u" name="Last_Name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Suffix</label>
							<input type="Suffix" id="Suffix_u" name="Suffix" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Gender</label>
							<select name="Gender" id="Gender">
								<option value="1">Male</option>
								<option value="2">Female</option></select>
						</div>
						<div class="form-group">
							<label>Date_of_Birth</label>
							<input type="date" id="Date_of_Birth_u" name="Date_of_Birth"><br><br>
						</div>
						<div class="form-group">
							<label>Place_of_Birth</label>
							<input type="Place_of_Birth" id="Place_of_Birth_u" name="Place_of_Birth" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Province</label>
							<input type="Province" id="Province_u" name="Province" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Country</label>
							<input type="Country" id="Country_u" name="Country" class="form-control" required>
						</div>
						
					</div>

					<div class="modal-footer">
					    <input type="hidden" value="1" name="type">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<button type="button" class="btn btn-success" id="btn-add">Add</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Edit Modal HTML -->
	<div id="editEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form id="update_form">
					<div class="modal-header">
						<h4 class="modal-title">Edit User</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<input type="hidden" id="id_u" name="id" class="form-control" required>
						<div class="form-group">
							<label>PID_Form_No</label>
							<input type="PID_Form_No" id="PID_Form_No_u" name="PID_Form_No" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Revision_No</label>
							<input type="date" id="Revision_No_u" name="Revision_No"><br><br>
						</div>
						<div class="form-group">
							<label>Application_Control_No</label>
							<input type="Application_Control_No" id="Application_Control_No_u" name="Application_Control_No" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Accepting_Post_Office_Code</label>
							<input type="Accepting_Post_Office_Code" id="Accepting_Post_Office_Code_u" name="Accepting_Post_Office_Code" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Accepting_Post_Office_Name</label>
							<input type="Accepting_Post_Office_Name" id="Accepting_Post_Office_Name_u" name="Accepting_Post_Office_Name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Or_No</label>
							<input type="Or_No" id="Or_No_u" name="Or_No" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Or_Date</label>
							<input type="date" id="Or_Date_u" name="Or_Date"><br><br>
						</div>
						<div class="form-group">
							<label>Postal_Reference_No</label>
							<input type="Postal_Reference_No" id="Postal_Reference_No_u" name="Postal_Reference_No" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Initial</label>
							<input type="Initial" id="Initial_u" name="Initial" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Renewal</label>
							<input type="Renewal" id="Renewal_u" name="Renewal" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Card_Replacement</label>
							<input type="Card_Replacement" id="Card_Replacement_u" name="Card_Replacement" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Amendment_of_Name</label>
							<input type="Amendment_of_Name" id="Amendment_of_Name_u" name="Amendment_of_Name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Replacement_of_Lost_Card</label>
							<input type="Replacement_of_Lost_Card" id="Replacement_of_Lost_Card_u" name="Replacement_of_Lost_Card" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Amendment_of_Biographic_Data</label>
							<input type="Amendment_of_Biographic_Data" id="Amendment_of_Biographic_Data_u" name="Amendment_of_Biographic_Data" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Amendment_of_Authenticating_Finger</label>
							<input type="Amendment_of_Authenticating_Finger" id="Amendment_of_Authenticating_Finger_u" name="Amendment_of_Authenticating_Finger" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Replacement_of_Damage_Card</label>
							<input type="Replacement_of_Damage_Card" id="Replacement_of_Damage_Card_u" name="Replacement_of_Damage_Card" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Others</label>
							<input type="Others" id="Others_u" name="Others" class="form-control" required>
						</div>
						<div class="form-group">
							<label>First_Name</label>
							<input type="First_Name" id="First_Name_u" name="First_Name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Middle_Name</label>
							<input type="Middle_Name" id="Middle_Name_u" name="Middle_Name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Last_Name</label>
							<input type="Last_Name" id="Last_Name_u" name="Last_Name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Suffix</label>
							<input type="Suffix" id="Suffix_u" name="Suffix" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Gender</label>
							<select name="Gender" id="Gender">
								<option value="1">Male</option>
								<option value="2">Female</option></select>
						</div>
						<div class="form-group">
							<label>Date_of_Birth</label>
							<input type="date" id="Date_of_Birth_u" name="Date_of_Birth"><br><br>
						</div>
						<div class="form-group">
							<label>Place_of_Birth</label>
							<input type="Place_of_Birth" id="Place_of_Birth_u" name="Place_of_Birth" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Province</label>
							<input type="Province" id="Province_u" name="Province" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Country</label>
							<input type="Country" id="Country_u" name="Country" class="form-control" required>
						</div>
					</div>
					<div class="modal-footer">
					<input type="hidden" value="2" name="type">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<button type="button" class="btn btn-info" id="update">Update</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Delete Modal HTML -->
	<div id="deleteEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form>

					<div class="modal-header">
						<h4 class="modal-title">Delete User</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<input type="hidden" id="id_d" name="id" class="form-control">
						<p>Are you sure you want to delete these Records?</p>
						<p class="text-warning"><small>This action cannot be undone.</small></p>
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<button type="button" class="btn btn-danger" id="delete">Delete</button>
					</div>
				</form>
			</div>
		</div>
	</div>

</body>
</html>
